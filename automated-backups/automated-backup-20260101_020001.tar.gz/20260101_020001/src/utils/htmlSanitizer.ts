
import DOMPurify from 'dompurify';

// Configure DOMPurify with secure defaults that preserve code formatting
const sanitizeConfig = {
  ALLOWED_TAGS: [
    'p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'blockquote', 
    'code', 'pre', 'span', 'div', 'img', 'kbd', 'samp', 'var'
  ],
  ALLOWED_ATTR: ['class', 'style', 'src', 'alt', 'width', 'height', 'data-*'],
  FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover'],
  FORBID_TAGS: ['script', 'object', 'embed', 'base', 'link', 'meta', 'iframe'],
  ALLOW_DATA_ATTR: true,
  ALLOWED_URI_REGEXP: /^(?:(?:(?:f|ht)tps?|mailto|tel|callto|cid|xmpp|blob|data):|[^a-z]|[a-z+.\-]+(?:[^a-z+.\-:]|$))/i,
};

export const sanitizeHtml = (html: string): string => {
  if (!html || typeof html !== 'string') {
    return '';
  }
  
  return DOMPurify.sanitize(html, sanitizeConfig);
};

export const formatAndSanitizeText = (text: string): string => {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // First format the text (convert **bold** to <strong> and newlines to <br>)
  const formatted = text
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br />')
    .replace(/  /g, '&nbsp;&nbsp;');
  
  // Then sanitize the HTML
  return sanitizeHtml(formatted);
};

export const stripHtml = (html: string): string => {
  if (!html || typeof html !== 'string') {
    return '';
  }
  
  return DOMPurify.sanitize(html, { ALLOWED_TAGS: [], ALLOWED_ATTR: [] });
};
