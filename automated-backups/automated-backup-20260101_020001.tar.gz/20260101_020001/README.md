# Source Edge Database Helper 
