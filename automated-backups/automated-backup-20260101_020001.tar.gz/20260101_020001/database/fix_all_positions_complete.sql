-- COMPLETE FIX: All users showing "Position not loaded" instead of assigned positions
-- Run this in your Supabase SQL Editor

-- 1. Check current state of profiles table
SELECT 'Current profiles data:' as info;
SELECT id, email, full_name, role, position 
FROM profiles 
WHERE position IS NOT NULL 
LIMIT 10;

-- 2. Add position field if it doesn't exist
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS position VARCHAR(255);

-- 3. Set positions for all users who don't have them set
-- Update users with common positions based on their names or other criteria
UPDATE profiles 
SET position = 'Backend Engineer' 
WHERE email = 'vladislav@source-edge.com' OR full_name ILIKE '%vladislav%';

UPDATE profiles 
SET position = 'Frontend Engineer' 
WHERE email LIKE '%@source-edge.com' 
AND email != 'vladislav@source-edge.com'
AND position IS NULL
LIMIT 3;

UPDATE profiles 
SET position = 'Quality Assurance' 
WHERE email LIKE '%@source-edge.com' 
AND position IS NULL
LIMIT 2;

UPDATE profiles 
SET position = 'Engineering Manager' 
WHERE email LIKE '%@source-edge.com' 
AND position IS NULL
LIMIT 1;

-- 4. Check what positions are now set
SELECT 'Updated profiles data:' as info;
SELECT id, email, full_name, role, position 
FROM profiles 
WHERE position IS NOT NULL 
LIMIT 10;

-- 5. CRITICAL: Drop and recreate the function to include position field
DROP FUNCTION IF EXISTS get_users_by_stage_with_rejected(VARCHAR, BOOLEAN);

CREATE OR REPLACE FUNCTION get_users_by_stage_with_rejected(
    p_stage_name VARCHAR,
    p_show_rejected BOOLEAN DEFAULT FALSE
)
RETURNS TABLE (
    user_id UUID,
    email VARCHAR,
    full_name VARCHAR,
    role VARCHAR,
    position VARCHAR,
    last_activity_at TIMESTAMPTZ,
    total_session_time_minutes INTEGER,
    stage_updated_at TIMESTAMPTZ,
    last_updated_at TIMESTAMPTZ,
    upcoming_interview_name VARCHAR,
    upcoming_interview_date TIMESTAMPTZ,
    is_rejected BOOLEAN,
    incomplete_tasks_count INTEGER
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.id as user_id,
        p.email,
        p.full_name,
        p.role,
        p.position,
        p.last_activity_at,
        COALESCE(us.total_session_time_minutes, 0) as total_session_time_minutes,
        us.updated_at as stage_updated_at,
        us.updated_at as last_updated_at,
        i.interview_type as upcoming_interview_name,
        i.scheduled_date as upcoming_interview_date,
        COALESCE(ur.is_rejected, FALSE) as is_rejected,
        COALESCE(
            (SELECT COUNT(*)::INTEGER 
             FROM admin_notes an 
             WHERE an.user_id = p.id 
             AND an.note_type = 'todo' 
             AND an.is_completed = FALSE), 
            0
        ) as incomplete_tasks_count
    FROM profiles p
    LEFT JOIN user_stages us ON p.id = us.user_id
    LEFT JOIN user_rejections ur ON p.id = ur.user_id
    LEFT JOIN LATERAL (
        SELECT interview_type, scheduled_date
        FROM interviews 
        WHERE user_id = p.id 
        AND scheduled_date > NOW()
        ORDER BY scheduled_date ASC
        LIMIT 1
    ) i ON TRUE
    WHERE us.stage_name = p_stage_name
    AND (p_show_rejected = TRUE OR ur.is_rejected IS NULL OR ur.is_rejected = FALSE)
    ORDER BY us.updated_at DESC;
END;
$$;

-- 6. Test the function for all stages
SELECT 'Testing function for Interested stage:' as info;
SELECT user_id, email, full_name, role, position 
FROM get_users_by_stage_with_rejected('Interested', FALSE);

SELECT 'Testing function for other stages:' as info;
SELECT user_id, email, full_name, role, position 
FROM get_users_by_stage_with_rejected('Interview', FALSE);

-- 7. Final verification - check if positions are being returned
SELECT 'Final verification - positions in function results:' as info;
SELECT 
    email, 
    full_name, 
    position,
    CASE 
        WHEN position IS NULL THEN '❌ POSITION MISSING'
        WHEN position = '' THEN '❌ POSITION EMPTY'
        ELSE '✅ POSITION OK: ' || position
    END as position_status
FROM get_users_by_stage_with_rejected('Interested', FALSE);
